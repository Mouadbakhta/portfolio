# Portfolio Mouad Bakhta - Java Back-End & DevOps

Portfolio professionnel de **Mouad Bakhta**, Élève Ingénieur en Génie Logiciel à l'ENSA Marrakech (CPGE MPSI/MP), spécialisé en **Java Back-End** & **DevOps**.
Recherche activement un **Stage de Fin d'Études (PFE)** démarrant en **Février 2026**.

## 🚀 Fonctionnalités Clés
- 🤖 **Assistant IA RAG** propulsé par **Groq (openai/gpt-oss-120b)** et **Gemini 3.1 Flash Lite**, connecté à vos CVs et vos dépôts GitHub.
- 🌐 **Bilingue Anglais / Français** avec sélecteur instantané `[EN / FR]`.
- 📁 **Projets d'Ingénierie & Architecture** avec focus sur les 4 projets en cours de déploiement (OkaneTransfer, Détection de Fraude, OrcaML, Optimisation de Livraison) et le projet DevOps Petclinic.
- 📬 **Formulaire de Contact Fiable** avec envoi direct, rédaction en 1 clic dans Gmail (sans mots de passe 16 caractères), et copie en un clic email/téléphone.
- 📄 **Téléchargement direct du CV Java & DevOps** en PDF.

## 🛠️ Déploiement Direct sur Vercel (Recommandé)
Ce dossier est 100% prêt pour Vercel (avec `vercel.json` et fonctions serverless `/api/chat.js` et `/api/contact.js`) :

1. Décompressez cette archive dans votre dossier de projet local (ou remplacez les fichiers dans votre dépôt existant `https://github.com/Mouadbakhta/portfolio.git`).
2. Faites un commit et poussez sur GitHub :
   ```bash
   git add .
   git commit -m "Update portfolio with Groq RAG chatbot, bilingual UI, and Vercel serverless functions"
   git push origin main
   ```
3. Sur votre tableau de bord **Vercel** :
   - Ajoutez la variable d'environnement `GROQ_API_KEY` = `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`
   - Vercel construira automatiquement l'application et déploiera les fonctions de l'API !

## 💻 Test en Local
```bash
npm install
npm run dev
```
Ouvrez `http://localhost:3000` dans votre navigateur.
